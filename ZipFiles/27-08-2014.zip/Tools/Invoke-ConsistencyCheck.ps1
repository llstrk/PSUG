﻿param (
    $ComputerName="localhost"
)

$params = @{
    Namespace  = 'root/Microsoft/Windows/DesiredStateConfiguration'
    ClassName  = 'MSFT_DSCLocalConfigurationManager'
    MethodName = 'PerformRequiredConfigurationChecks'
    Arguments  = @{
        Flags = [uint32] 1
    }
}

Invoke-CimMethod @params -ComputerName $ComputerName